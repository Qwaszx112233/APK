// errorHandler.js — глобальный контроль ошибок (без сервера)
class ErrorHandler {
  static _installed = false;
  static _game = null;
  static _counter = 0;

  static install() {
    if (this._installed) return;
    this._installed = true;

    // ВАЖНО: ресурсные ошибки (404 скрипта/стиля/картинки) ловятся только в capture=true
    window.addEventListener("error", (ev) => {
      try {
        // 1) Resource loading error (script/css/img) — ev.error обычно пустой
        const t = ev.target || ev.srcElement;
        const url = t && (t.src || t.href) ? (t.src || t.href) : null;
        if (!ev.error && url) {
          this.handle(`Resource load failed: ${t.tagName || "RESOURCE"} ${url}`, {
            type: "resource",
            tag: t.tagName,
            url
          });
          return;
        }

        // 2) Normal runtime error
        const err = ev.error || ev.message || "Unknown error";
        this.handle(err, {
          type: "error",
          filename: ev.filename,
          lineno: ev.lineno,
          colno: ev.colno
        });
      } catch (e) {
        // если сам обработчик упал — не зацикливаемся
        try { console.error("[ErrorHandler] internal error", e); } catch (_) {}
      }
    }, true);
    window.addEventListener("unhandledrejection", (ev) => {
      this.handle(ev.reason || "Unhandled rejection", { type: "unhandledrejection" });
    });
  }

  static setGame(game) {
    this._game = game || null;
  }

  static _id() {
    this._counter++;
    return `LN-${Date.now().toString(36)}-${this._counter.toString(36)}`;
  }

  static _ctx() {
    const g = this._game || window.game;
    if (!g) return { hasGame: false };

    return {
      hasGame: true,
      screen: g.screenState,
      phase: g.gamePhase,
      level: g.currentLevel,
      target: g.levelTarget,
      xp: g.xp,
      seed: (g.state && g.state.currentSeed) || g.currentSeed,
      lastSpinBonus: g.lastSpinBonus
    };
  }

  static handle(err, meta = {}) {
    const id = this._id();
    const e = (err instanceof Error) ? err : new Error(String(err));
    const ctx = this._ctx();

    console.groupCollapsed(`%c[LostNumber ERROR] ${id}`, "color:#ff6b9d;font-weight:900");
    console.log("meta:", meta);
    console.log("ctx:", ctx);
    console.error(e);
    console.groupEnd();

    // мягкое уведомление игроку (если UI готов)
    try {
      const g = this._game || window.game;
      if (g && typeof g.showMessage === "function") {
        g.showMessage(`${g.t ? g.t("error_generic") : "Помилка"} (${id})`);
      }
    } catch (_) {}
  }
}
ErrorHandler.install();