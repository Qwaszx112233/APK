class SettingsManager {
  constructor(game) {
    this.game = game;
  }

  setupSettings() {
    document.getElementById("backFromSettingsBtn").addEventListener("click", () => {
      this.game.audioManager.playTap();
      this.game.screenManager.showScreen("mainMenu");
    });
    
    document.getElementById("saveSettingsBtn").addEventListener("click", () => {
      this.game.audioManager.playTap();

      this.game.animationEnabled = document.getElementById("animationSelect").value === "on";
      this.game.soundEnabled = document.getElementById("soundSelect").value === "on";
      this.game.theme = document.getElementById("themeSelect")?.value || "dusk";
      const newLang = document.getElementById("languageSelect").value || "ua";
      
      this.game.audioManager.setSoundEnabled(this.game.soundEnabled);
      this.game.audioManager.updateSoundStateUI(); // Обновляем иконку звука
      this.game.applyLanguage(newLang);
      this.game.saveSettings();
      this.game.screenManager.showScreen("mainMenu");
    });

    document.getElementById("backFromDailyQuestsBtn").addEventListener("click", () => {
      this.game.audioManager.playTap();
      this.game.screenManager.showScreen("mainMenu");
    });
    
    document.getElementById("backFromAchievementsBtn").addEventListener("click", () => {
      this.game.audioManager.playTap();
      this.game.screenManager.showScreen("mainMenu");
    });
    
    document.getElementById("backFromStatsBtn").addEventListener("click", () => {
      this.game.audioManager.playTap();
      this.game.screenManager.showScreen("mainMenu");
    });
    
    document.getElementById("backFromAboutBtn").addEventListener("click", () => {
      this.game.audioManager.playTap();
      this.game.screenManager.showScreen("mainMenu");
    });
  }

  loadSettings() {
    const settings = this.game.storageManager.loadSettings();
    
    if (settings) {
      this.game.animationEnabled = settings.animationEnabled !== false;
      this.game.soundEnabled = settings.soundEnabled !== false;
      this.game.theme = settings.theme || this.game.theme || "dusk";
      this.game.lang = settings.lang || this.game.lang || "ua";
    }
  }

  saveSettings() {
    const settings = {
      animationEnabled: this.game.animationEnabled !== false,
      soundEnabled: this.game.soundEnabled !== false,
      theme: this.game.theme || "dusk",
      lang: this.game.lang || "ua"
    };
    
    this.game.storageManager.saveSettings(settings);
  }
}