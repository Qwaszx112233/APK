class ScreenManager {
  constructor(game) {
    this.game = game;
  }

  showScreen(name) {
    const wasGame = this.game.screenState === "game";
    this.game.screenState = name;

    document.querySelectorAll(".screen").forEach(screen => {
      screen.classList.add("hidden");
    });

    const target = document.getElementById(name + "Screen");
    if (target) target.classList.remove("hidden");

    if (wasGame && name !== "game") {
      this.game.resetRuntimeState();
    }
  }

  createFloatingNumbers() {
    const container = document.getElementById("floatingHearts");
    const count = 14;
    const symbols = ["2","4","8","16","32","64","128"];
    
    for (let i = 0; i < count; i++) {
      const h = document.createElement("div");
      h.className = "floating-heart";
      h.textContent = symbols[Math.floor(Math.random() * symbols.length)];
      h.style.left = Math.random() * 100 + "vw";
      h.style.top = Math.random() * 100 + "vh";
      h.style.animationDelay = Math.random() * 7 + "s";
      h.style.fontSize = (0.9 + Math.random() * 1.2) + "rem";
      container.appendChild(h);
    }
  }
}