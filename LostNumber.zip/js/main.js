class LostNumberGame {
  constructor() {
    // Инициализация менеджеров
    this.storageManager = new StorageManager();
    this.audioManager = new AudioManager();
    this.screenManager = new ScreenManager(this);
    this.menuManager = new MenuManager(this);
    this.settingsManager = new SettingsManager(this);
    this.overlayManager = new OverlayManager(this);
    
    // Инициализация игрового состояния
    this.state = new GameState();

    // Seeded Random (session + daily)
    this.initSeededRandom();
    
    // Копируем свойства из состояния для обратной совместимости
    Object.assign(this, this.state);
    
    // Инициализация менеджеров игровых систем
    this.gridManager = new GridManager(this);
    this.bonusManager = new BonusManager(this);
    this.wheelManager = new WheelManager(this);
    this.achievementManager = new AchievementManager(this);
    this.dailyQuestManager = new DailyQuestManager(this);
    this.statsManager = new StatsManager(this);
    
    // Привязка менеджеров
    this.state.gridManager = this.gridManager;
    
    // Инициализация
    this.createFloatingNumbers = this.screenManager.createFloatingNumbers.bind(this.screenManager);
    this.showScreen = this.screenManager.showScreen.bind(this.screenManager);
    this.showMessage = this.overlayManager.showMessage.bind(this.overlayManager);
    this.updatePreviewBubble = this.overlayManager.updatePreviewBubble.bind(this.overlayManager);
    this.hidePreviewBubble = this.overlayManager.hidePreviewBubble.bind(this.overlayManager);
    this.showVictory = this.overlayManager.showVictory.bind(this.overlayManager);
    this.hideVictory = this.overlayManager.hideVictory.bind(this.overlayManager);
    
    // Явное копирование методов из GameState
    this.formatNumber = this.state.formatNumber.bind(this.state);
    this.getWheelCost = this.state.getWheelCost.bind(this.state);
    this.checkWheelDailyReset = this.state.checkWheelDailyReset.bind(this.state);
    this.baseXPByLen = this.state.baseXPByLen.bind(this.state);
    this.levelXPMult = this.state.levelXPMult.bind(this.state);
    this.calculateXP = this.state.calculateXP.bind(this.state);
    this.getAllowedNumbers = this.state.getAllowedNumbers.bind(this.state);
    this.generateCellNumber = this.state.generateCellNumber.bind(this.state);
    this.pickWeighted = this.state.pickWeighted.bind(this.state);
    this.getTodayKey = this.state.getTodayKey.bind(this.state);
    this.generateAASuffix = this.state.generateAASuffix.bind(this.state);
    this.generateLevels = this.state.generateLevels.bind(this.state);
    this.defaultStats = this.state.defaultStats.bind(this.state);
    this.defaultAchievements = this.state.defaultAchievements.bind(this.state);
    this.setGamePhase = this.state.setGamePhase.bind(this.state);
    this.resetRuntimeState = this.state.resetRuntimeState.bind(this.state);
    
    // Инициализация ежедневных заданий
    this.dailyQuests = this.dailyQuestManager.loadDailyQuests();
    
    // ДОБАВЛЕНО: Методы для обратной совместимости
    this.updateAchievementProgress = this.updateAchievementProgress.bind(this);
    this.updateBonusesUI = this.updateBonusesUI.bind(this);
    this.completeDailyQuest = this.completeDailyQuest.bind(this);
    
    this.isFirstRun = this.storageManager.isFirstRun();
    if (this.isFirstRun) {
      this.storageManager.markFirstRunComplete();
    }

    this.createFloatingNumbers();
    this.setupUI();
    this.settingsManager.loadSettings();
    this.applyLanguage(this.lang || "ua");
    this.applyTheme();
    this.checkExistingSave();
    this.showScreen("mainMenu");
    
    // Debug overlay (Ctrl+D) — только в dev режиме или при ?dev=1
    try {
      if (typeof DebugOverlay !== "undefined") {
        this.debugOverlay = new DebugOverlay(this);
        this.debugOverlay.init();
      }
    } catch (e) {}

    // Error boundaries
    try {
      if (typeof ErrorBoundary !== "undefined") {
        ErrorBoundary.wrap(this.core, "validateMove", () => false, "GameCore.validateMove");
        ErrorBoundary.wrap(this.gridManager, "render", () => {}, "GridManager.render");
        ErrorBoundary.wrap(this.wheelManager, "spinWheel", () => {
          this.xp += 15;
          this.updateXPBar();
          this.showMessage(this.t("wheel_fallback_xp") || "+15 XP");
        }, "WheelManager.spinWheel");
        ErrorBoundary.wrap(this.bonusManager, "activateBonus", () => {
          this.showMessage(this.t("bonus_error") || "Бонус недоступний");
        }, "BonusManager.activateBonus");
        ErrorBoundary.wrap(this.storageManager, "loadGameState", () => null, "StorageManager.loadGameState");
        ErrorBoundary.wrap(this.storageManager, "saveGameState", () => {}, "StorageManager.saveGameState");
      }
    } catch (e) {}

    document.addEventListener("contextmenu", e => e.preventDefault());
  }
  
  // Seeded RNG — один источник случайности на сессию + daily seed
  initSeededRandom(forceNew = false) {
    const KEY = "lostNumberSessionSeed";
    let seed = 0;

    if (!forceNew) {
      try {
        const saved = localStorage.getItem(KEY);
        if (saved && /^\d+$/.test(saved)) seed = (parseInt(saved, 10) >>> 0);
      } catch (_) {}
    }

    if (!seed) {
      try {
        seed = (typeof SeededRandom !== "undefined" && SeededRandom.makeSessionSeed)
          ? SeededRandom.makeSessionSeed()
          : ((Date.now() & 0xffffffff) >>> 0);
      } catch (_) {
        seed = ((Date.now() & 0xffffffff) >>> 0);
      }
      try { localStorage.setItem(KEY, String(seed >>> 0)); } catch (_) {}
    }

    this.currentSeed = seed >>> 0;
    this.rng = new SeededRandom(this.currentSeed);

    // daily seed (локальная дата, одинаковая для всех сегодня)
    try {
      const d = new Date();
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      const dailyKey = `${yyyy}-${mm}-${dd}|daily|lostnumber-v1`;
      this.dailySeed = (typeof SeededRandom !== "undefined" && SeededRandom.hashToSeed)
        ? SeededRandom.hashToSeed(dailyKey)
        : (this.currentSeed ^ 0x9E3779B9);
      this.dailyRng = new SeededRandom(this.dailySeed);
    } catch (_) {
      this.dailySeed = (this.currentSeed ^ 0x9E3779B9) >>> 0;
      this.dailyRng = new SeededRandom(this.dailySeed);
    }

    // пробрасываем в state (его используют grid/wheel)
    try {
      if (this.state) {
        this.state.rng = this.rng;
        this.state.currentSeed = this.currentSeed;
      }
    } catch (_) {}
  }

  // DebugOverlay command: resetSeed()
  resetSeed() {
    try { localStorage.removeItem("lostNumberSessionSeed"); } catch (_) {}
    this.initSeededRandom(true);
    try { this.showMessage?.(`Seed: ${this.currentSeed}`); } catch (_) {}
    try { if (this.debugOverlay && this.debugOverlay.update) this.debugOverlay.update(); } catch (_) {}
  }

  // DebugOverlay command: forceError()
  forceError() {
    throw new Error("Forced error (debug)");
  }

  // DebugOverlay command: skipLevel()
  skipLevel() {
    try {
      this.setGamePhase?.("win");
      this.handleLevelComplete?.();
      this.showMessage?.("DEV: level skipped");
    } catch (e) {
      try { if (typeof ErrorHandler !== "undefined") ErrorHandler.handle(e, { where: "skipLevel" }); } catch (_) {}
    }
  }

  // DebugOverlay helper (не обязателен): addBonus(type, count)
  addBonus(type, count = 1) {
    try {
      if (!type) return;
      if (!this.bonusInventory) this.bonusInventory = {};
      this.bonusInventory[type] = (this.bonusInventory[type] || 0) + (Number(count) || 1);
      this.updateBonusesUI?.();
      this.saveGameState?.();
      this.showMessage?.(`+${count} ${type}`);
    } catch (e) {
      try { if (typeof ErrorHandler !== "undefined") ErrorHandler.handle(e, { where: "addBonus", type, count }); } catch (_) {}
    }
  }
  // НОВЫЙ МЕТОД: Убедиться что обработчики grid привязаны
  ensureGridEventListeners() {
    const grid = document.getElementById("grid");
    if (!grid) return;
    
    // Проверяем есть ли уже обработчики
    const hasListeners = grid._listenersAttached || false;
    
    if (!hasListeners) {
      // Привязываем обработчики
      const onDown = (e) => this.handlePointerDown(e);
      const onMove = (e) => this.handlePointerMove(e);
      const onUp = (e) => this.handlePointerUp(e);

      grid.addEventListener("pointerdown", onDown, { passive: false });
      grid.addEventListener("pointermove", onMove, { passive: false });
      grid.addEventListener("pointerup", onUp, { passive: false });
      grid.addEventListener("pointercancel", onUp, { passive: false });

      // сохраняем ссылки (на всякий)
      grid._lnHandlers = { onDown, onMove, onUp };
      
      // Помечаем что обработчики привязаны
      grid._listenersAttached = true;
      console.log("✅ Grid обработчики привязаны");
    }
  }

  applyLanguage(lang) {
    this.lang = lang;
    const langAttr = lang === "ua" ? "uk" : lang;
    document.documentElement.lang = langAttr;
    document.title = this.t("app_title");

    this.renderStaticI18n();
    this.renderDynamicUI();
  }
  
  renderStaticI18n() {
    document.querySelectorAll("[data-i18n]").forEach(el => {
      const key = el.getAttribute("data-i18n");
      if (!key) return;
      el.textContent = this.t(key);
    });

    document.querySelectorAll("[data-i18n-title]").forEach(el => {
      const key = el.getAttribute("data-i18n-title");
      if (!key) return;
      el.title = this.t(key);
    });
  }
  
  renderDynamicUI() {
    this.updateXPBar();
    this.updateGoal();
    if (this.dailyQuestManager) {
      this.dailyQuestManager.renderDailyQuests();
    }
    if (this.statsManager) {
      this.statsManager.renderStats();
    }
    if (this.wheelManager) {
      this.wheelManager.updateWheelUI();
    }
    if (this.bonusManager) {
      this.bonusManager.updateBonusesUI();
    }
    if (this.achievementManager) {
      this.achievementManager.renderAchievementsScreen();
    }
    this.applyTheme();
    if (this.audioManager) {
      this.audioManager.updateSoundStateUI();
    }
    this.updateMultiplierIndicator();
  }
  
  t(key) {
    const pack = I18N[this.lang] || I18N["ua"];
    return pack[key] || key;
  }

  formatTemplate(key, params) {
    let text = this.t(key);
    Object.keys(params || {}).forEach(k => {
      text = text.replace(`{${k}}`, params[k]);
    });
    return text;
  }

  applyTheme() {
    const root = document.documentElement;
    root.setAttribute("data-theme", this.theme || "dusk");
  }

  checkExistingSave() {
    const raw = this.storageManager.loadGameState();
    const continueBtn = document.getElementById("continueBtn");

    if (!raw) {
      this.hasSave = false;
      if (continueBtn) { continueBtn.disabled = true; continueBtn.style.opacity = "0.5"; }
      return;
    }
    
    this.hasSave = true;
    if (continueBtn) { continueBtn.disabled = false; continueBtn.style.opacity = "1"; }
  }
  
  showAchievementsScreen() {
    if (this.achievementManager) {
      this.achievementManager.renderAchievementsScreen();
    }
    this.showScreen("achievements");
  }
  
  showStatsScreen() {
    if (this.statsManager) {
      this.statsManager.renderStats();
    }
    this.showScreen("stats");
  }
  
  resumeGame() {
    const data = this.storageManager.loadGameState();

    this.resetRuntimeState();

    if (!data) {
      this.startNewGame();
      return;
    }

    try {
      this.restoreFromState(data);

      this.applyLanguage(this.lang || "ua");
      this.applyTheme();
      if (this.audioManager) {
        this.audioManager.updateSoundStateUI();
      }

      this.setGamePhase("playing");
      this.showScreen("game");
      
      // ФИКСАЦИЯ: Восстанавливаем структуру grid, если она была сохранена как массив чисел
      this.fixGridStructure();
      
      if (this.gridManager) {
        this.gridManager.render();
      }
      if (this.wheelManager) {
        this.wheelManager.updateWheelUI();
      }
    } catch (e) {
      console.error("Resume fail, starting new:", e);
      this.startNewGame();
    }
  }
  
  // НОВЫЙ МЕТОД: Исправление структуры grid
  fixGridStructure() {
    if (!this.grid || !Array.isArray(this.grid)) {
      // Если grid не существует, создаем новую
      this.gridManager.initGame(this.currentLevel);
      return;
    }
    
    // Проверяем каждый элемент grid
    for (let x = 0; x < this.GRID_W; x++) {
      if (!this.grid[x] || !Array.isArray(this.grid[x])) {
        this.grid[x] = [];
      }
      
      for (let y = 0; y < this.GRID_H; y++) {
        let cellData = this.grid[x][y];
        
        // Если это число, а не объект, преобразуем в объект
        if (typeof cellData === 'number' || cellData === null || cellData === undefined) {
          this.grid[x][y] = {
            number: typeof cellData === 'number' ? cellData : this.generateCellNumber(),
            merged: false,
            frozen: false
          };
        }
        // Если это объект, но не имеет нужных свойств
        else if (typeof cellData === 'object' && cellData !== null) {
          if (cellData.number === undefined) {
            cellData.number = this.generateCellNumber();
          }
          if (cellData.merged === undefined) {
            cellData.merged = false;
          }
          if (cellData.frozen === undefined) {
            cellData.frozen = false;
          }
        }
      }
    }
  }
  
  restoreFromState(state) {
    // Восстанавливаем основные свойства
    this.currentLevel = state.currentLevel || 0;
    this.xp = state.xp || 0;
    this.xpMultiplier = state.xpMultiplier || 1;
    this.xpMultiplierTurns = state.xpMultiplierTurns || 0;
    this.grid = state.grid || [];
    this.bonusInventory = state.bonusInventory || { destroy: 0, shuffle: 0, explosion: 0 };
    this.pendingTransition = state.pendingTransition || null;
    this.maxReachedNumber = state.maxReachedNumber || 8;
    this.carryNumber = state.carryNumber || null;
    this.stats = state.stats || this.defaultStats();
    this.achievements = state.achievements || this.defaultAchievements();
    this.wheelSpinsToday = state.wheelSpinsToday || 0;
    this.lastWheelDay = state.lastWheelDay || this.getTodayKey();
    this.animationEnabled = state.animationEnabled !== undefined ? state.animationEnabled : true;
    this.soundEnabled = state.soundEnabled !== undefined ? state.soundEnabled : true;
    this.theme = state.theme || "dawn";
    this.lang = state.lang || "ua";
    
    // Восстанавливаем frozenCells
    if (state.frozenCells) {
      this.frozenCells = new Map(Object.entries(state.frozenCells).map(([k, v]) => [Number(k), v]));
    } else {
      this.frozenCells = new Map();
    }

    this.dailyQuests = this.dailyQuestManager.loadDailyQuests();
    this.checkWheelDailyReset();
    
    if (this.pendingTransition && this.pendingTransition.active) {
      this.currentLevel = Math.min(this.pendingTransition.nextLevel, this.MAX_LEVEL - 1);
      this.carryNumber = this.pendingTransition.carryNumber ?? null;
      this.pendingTransition = null;
      this.gridManager.initGame(this.currentLevel);
      this.saveGameState();
    } else {
      this.updateTargetInfo();
      this.updateXPBar();
      if (this.bonusManager) {
        this.bonusManager.updateBonusesUI();
      }
      if (this.wheelManager) {
        this.wheelManager.updateWheelUI();
      }
    }
  }
  
  updateTargetInfo() {
    const level = this.levels[this.currentLevel];
    if (level && level.target) {
      const targetValue = document.getElementById("targetValue");
      const levelLabel = document.getElementById("levelLabel");
      
      if (targetValue) {
        targetValue.textContent = this.formatNumber(level.target);
      }
      if (levelLabel) {
        levelLabel.textContent = this.formatTemplate("level_label", { level: this.currentLevel + 1 });
      }
    }
  }

  updateXPBar() {
    const bar = document.getElementById("xpBar");
    const txt = document.getElementById("xpText");
    if (bar && txt) {
      bar.style.width = "100%";
      const xpText = this.formatTemplate("xp_label", { xp: this.formatNumber(this.xp) });
      txt.textContent = xpText;
      this.updateMultiplierIndicator();
    }
  }

  updateMultiplierIndicator() {
    const indicator = document.getElementById("xpMultiplierIndicator");
    if (!indicator) return;
    
    if (this.xpMultiplier > 1 && this.xpMultiplierTurns > 0) {
      indicator.textContent = this.formatTemplate("xp_multiplier_active", { turns: this.xpMultiplierTurns });
      indicator.style.display = "block";
    } else {
      indicator.style.display = "none";
    }
  }

  updateGoal() {
    if (this.currentLevel !== undefined && this.levels && this.levels[this.currentLevel]) {
      const level = this.levels[this.currentLevel];
      const targetValue = document.getElementById("targetValue");
      const levelLabel = document.getElementById("levelLabel");
      
      if (targetValue) {
        targetValue.textContent = this.formatNumber(level.target);
      }
      if (levelLabel) {
        levelLabel.textContent = this.formatTemplate("level_label", { level: this.currentLevel + 1 });
      }
    }
  }

  updateAchievementProgress(key, value = 1) {
    if (this.achievementManager) {
      this.achievementManager.updateAchievementProgress(key, value);
    }
  }
  
  updateBonusesUI() {
    if (this.bonusManager) {
      this.bonusManager.updateBonusesUI();
    }
  }
  
  completeDailyQuest(id) {
    if (this.dailyQuestManager) {
      return this.dailyQuestManager.completeDailyQuest(id);
    }
    return false;
  }

  startNewGame() {
    console.log("Starting new game...");
    
    this.currentLevel = 0;
    this.xp = 0;
    this.xpMultiplier = 1;
    this.xpMultiplierTurns = 0;
    this.bonusInventory = { destroy:0, shuffle:0, explosion:0 };
    this.frozenCells.clear();
    this.stats = this.defaultStats();
    this.achievements = this.defaultAchievements();
    this.pendingTransition = null;
    
    this.maxReachedNumber = 8;
    this.carryNumber = null;
    
    this.checkWheelDailyReset();

    this.resetRuntimeState();
    
    // ИНИЦИАЛИЗИРУЕМ ИГРОВОЕ ПОЛЕ
    this.gridManager.initGame(0);

    this.setGamePhase("playing");
    this.showScreen("game");
    
    // ОБНОВЛЯЕМ UI ПОСЛЕ ИНИЦИАЛИЗАЦИИ
    this.updateTargetInfo();
    this.updateXPBar();
    if (this.bonusManager) {
      this.bonusManager.updateBonusesUI();
    }
    if (this.wheelManager) {
      this.wheelManager.updateWheelUI();
    }
    
    this.saveGameState();
    this.stats.gamesPlayed++;
    
    console.log("New game started successfully");
  }

  setupUI() {
    this.menuManager.setupMainMenu();
    this.settingsManager.setupSettings();
    this.overlayManager.setupOverlays();

    const bonusWheelBtn = document.getElementById("bonus-wheel");
    if (bonusWheelBtn) {
      bonusWheelBtn.addEventListener("click", () => {
        this.audioManager.playTap();
        this.wheelManager.handleWheel();
      });
    }

    const bonusDestroyBtn = document.getElementById("bonus-destroy");
    if (bonusDestroyBtn) {
      bonusDestroyBtn.addEventListener("click", () => {
        this.audioManager.playTap();
        this.bonusManager.activateBonus("destroy");
      });
    }
    
    const bonusShuffleBtn = document.getElementById("bonus-shuffle");
    if (bonusShuffleBtn) {
      bonusShuffleBtn.addEventListener("click", () => {
        this.audioManager.playTap();
        this.bonusManager.activateBonus("shuffle");
      });
    }
    
    const bonusExplosionBtn = document.getElementById("bonus-explosion");
    if (bonusExplosionBtn) {
      bonusExplosionBtn.addEventListener("click", () => {
        this.audioManager.playTap();
        this.bonusManager.activateBonus("explosion");
      });
    }

    const footerHomeBtn = document.getElementById("footerHomeBtn");
    if (footerHomeBtn) {
      footerHomeBtn.addEventListener("click", () => {
        this.audioManager.playTap();
        this.setGamePhase("blocked");
        this.showScreen("mainMenu");
        this.saveGameState();
      });
    }

    const footerSoundBtn = document.getElementById("footerSoundBtn");
    if (footerSoundBtn) {
      footerSoundBtn.addEventListener("click", () => {
        this.audioManager.playTap();
        this.soundEnabled = !this.soundEnabled;
        this.audioManager.setSoundEnabled(this.soundEnabled);
        this.audioManager.updateSoundStateUI();
        this.saveGameState();
      });
    }

    const footerSaveBtn = document.getElementById("footerSaveBtn");
    if (footerSaveBtn) {
      footerSaveBtn.addEventListener("click", () => {
        this.audioManager.playTap();
        this.saveGameState();
        this.showMessage(this.t("save_done"));
      });
    }

    // ВАЖНОЕ ИСПРАВЛЕНИЕ: Привязываем обработчики grid
    this.ensureGridEventListeners();
  }

  handlePointerDown(e) {
    console.log("Pointer down");
    if (this.gamePhase !== "playing") return;
    
    const posCell = this.gridManager.getCellFromPoint(e.clientX, e.clientY);
    if (!posCell) {
      console.log("No cell found");
      return;
    }

    const idx = posCell.y * this.GRID_W + posCell.x;
    if (this.frozenCells.has(idx)) {
      this.showMessage(this.t("cell_frozen"));
      return;
    }

    if (this.activeBonus === "destroy") { 
      if (this.bonusInventory.destroy <= 0) {
        this.showMessage(this.t("no_bonus"));
        return;
      }
      this.bonusManager.useDestroyBonus(posCell.x, posCell.y); 
      return; 
    }
    if (this.activeBonus === "explosion") { 
      if (this.bonusInventory.explosion <= 0) {
        this.showMessage(this.t("no_bonus"));
        return;
      }
      this.bonusManager.useExplosionBonus(posCell.x, posCell.y); 
      return; 
    }

    this.isDragging = true;
    this.selected = [posCell];
    Chain.numbers = [this.grid[posCell.x][posCell.y].number];
    updateChainSum();
    this.updatePreviewBubble();
    this.gridManager.render();
  }

  handlePointerMove(e) {
    if (!this.isDragging || this.activeBonus) return;
    e.preventDefault();

    const posCell = this.gridManager.getCellFromPoint(e.clientX, e.clientY);
    if (!posCell) return;

    const idx = posCell.y * this.GRID_W + posCell.x;
    if (this.frozenCells.has(idx)) return;

    const len = this.selected.length;
    if (len === 0) return;

    if (len >= 2) {
      const prev = this.selected[len - 2];
      if (prev.x === posCell.x && prev.y === posCell.y) {
        this.selected.pop();
        Chain.numbers.pop();
        updateChainSum();
        this.updatePreviewBubble();
        this.gridManager.render();
        return;
      }
    }

    if (this.selected.some(s => s.x === posCell.x && s.y === posCell.y)) {
      return;
    }

    const last = this.selected[len - 1];
    if (!this.core.isAdjacent(last, posCell)) return;

    const newNum = this.grid[posCell.x][posCell.y].number;
    const prevNum = Chain.numbers[Chain.numbers.length - 1];
    const currentSum = Chain.sum;

    if (!this.core.isValidNextNumber(newNum, prevNum, currentSum)) return;

    this.selected.push(posCell);
    Chain.numbers.push(newNum);
    updateChainSum();

    this.updatePreviewBubble();
    this.gridManager.render();
  }

  handlePointerUp(e) {
    console.log("Pointer up, selected:", this.selected.length);
    if (!this.isDragging) return;
    this.isDragging = false;
    this.hidePreviewBubble();

    if (this.core.canFinishChain(Chain)) {
      console.log("Chain is valid, merging...");
      this.mergeChain();
    } else {
      console.log("Chain invalid, resetting");
      this.resetRuntimeState();
      this.showMessage(this.t("chain_invalid"));
    }
  }

  mergeChain() {
    console.log("Merging chain of", this.selected.length, "cells");
    
    const level = this.levels[this.currentLevel];
    const sum = Chain.sum;
    const target = level.target;
    const isLevelComplete = sum >= target;
    const resultNumber = isLevelComplete ? target : sum;
    
    this.maxReachedNumber = Math.max(this.maxReachedNumber, resultNumber);

    const surplus = isLevelComplete ? Math.max(0, sum - target) : 0;

    if (Chain.numbers.length < 2) {
      this.resetChain("invalid");
      return;
    }

    if (!this.core.canFinishChain(Chain)) {
      this.resetChain("invalid");
      return;
    }

    const anchor = this.selected[this.selected.length - 1];
    const removedCells = this.selected.slice(0, -1);

    console.log("Anchor cell:", anchor, "Removed cells:", removedCells.length);
    
    // Сохраняем якорную клетку
    this.grid[anchor.x][anchor.y].number = resultNumber;
    this.grid[anchor.x][anchor.y].merged = true;
    
    // Удаляем остальные клетки из цепочки
    removedCells.forEach(cell => {
      this.grid[cell.x][cell.y].number = null;
    });
    
    console.log("Before gravity - anchor:", this.grid[anchor.x][anchor.y].number);
    
    this.gridManager.render();

    this.gridManager.animatePopping(removedCells, () => {
      this.gridManager.animateGravity(removedCells, () => {
        // ВАЖНО: Вызываем гравитацию для заполнения пустых ячеек
        console.log("Applying local gravity...");
        this.gridManager.applyLocalGravity(removedCells);

        const xpEarned = this.calculateXP(this.selected.length);
        this.xp += xpEarned;
        
        this.stats.totalXP += xpEarned;
        this.stats.totalMerges++;
        if (this.selected.length > this.stats.longestChain) {
          this.stats.longestChain = this.selected.length;
        }
        
        this.achievementManager.updateAchievementProgress("chain5", this.selected.length >= 5 ? 1 : 0);
        this.achievementManager.updateAchievementProgress("chain10", this.selected.length >= 10 ? 1 : 0);
        this.achievementManager.updateAchievementProgress("xp1000", xpEarned);
        this.achievementManager.updateAchievementProgress("xp5000", xpEarned);
        
        if (this.selected.length >= 5) {
          this.dailyQuestManager.completeDailyQuest("chain5");
        }
        
        if (this.xp >= 100) {
          this.dailyQuestManager.completeDailyQuest("xp100");
        }
        
        if (surplus > 0) {
          this.xp += surplus;
          this.stats.totalXP += surplus;
          this.showMessage(this.formatTemplate("surplus_xp", { surplus }));
        }

        // ВАЖНОЕ ИСПРАВЛЕНИЕ: Очищаем selected ДО вызова render
        const oldSelected = [...this.selected]; // Сохраняем для очистки DOM
        this.selected = [];
        Chain.numbers = [];
        Chain.sum = 0;

        // Очищаем подсветку в DOM
        this.clearSelectionHighlight(oldSelected);

        this.updateXPBar();
        this.bonusManager.updateBonusesUI();
        this.gridManager.tickFrozenCells();
        
        // ВАЖНО: Вызываем render ПОСЛЕ очистки selected
        this.gridManager.render();
        
        this.saveGameState();
        this.checkWin();
      });
    });
  }
  
  // НОВЫЙ МЕТОД: Очистка подсветки в DOM
  clearSelectionHighlight(selectedCells) {
    const gridDiv = document.getElementById("grid");
    if (!gridDiv) return;
    
    selectedCells.forEach(cell => {
      const cellEl = gridDiv.querySelector(`.cell[data-x="${cell.x}"][data-y="${cell.y}"]`);
      if (cellEl) {
        cellEl.classList.remove("selected");
      }
    });
  }

  checkWin() {
    const level = this.levels[this.currentLevel];
    for (let x = 0; x < this.GRID_W; x++) {
      for (let y = 0; y < this.GRID_H; y++) {
        if (this.grid[x][y].number === level.target) {
          this.setGamePhase("win");
          this.handleLevelComplete();
          return;
        }
      }
    }
  }

  handleLevelComplete() {
    const oldXp = this.xp;
    const level = this.levels[this.currentLevel];
    const carryNumber = level.target;

    this.xp = oldXp;
    this.updateXPBar();
    this.bonusManager.updateBonusesUI();

    const prevLevelIndex = this.currentLevel;
    const prevLevelNumber = prevLevelIndex + 1;
    const nextLevelIndex = Math.min(prevLevelIndex + 1, this.MAX_LEVEL - 1);
    const nextLevelNumber = nextLevelIndex + 1;

    this.carryNumber = carryNumber;
    this.pendingTransition = { active: true, nextLevel: nextLevelIndex, carryNumber: carryNumber };
    this.saveGameState();
    
    this.stats.levelsCompleted++;
    if (nextLevelNumber > this.stats.highestLevel) {
      this.stats.highestLevel = nextLevelNumber;
    }
    
    this.achievementManager.updateAchievementProgress("level10", 1);
    this.achievementManager.updateAchievementProgress("level25", 1);
    
    this.dailyQuestManager.completeDailyQuest("completeLevel");
    
    const overlay = document.getElementById("levelOverlay");
    const title = document.getElementById("levelOverlayTitle");
    const text = document.getElementById("levelOverlayText");
    const stats = document.getElementById("levelStats");
    const countdown = document.getElementById("levelCountdown");
    const power = Math.log2(level.target);

    if (title) title.textContent = this.formatTemplate("level_completed_title");
    if (text) text.innerHTML = this.formatTemplate("level_new_number", { power: power, target: this.formatNumber(level.target) });
    
    let statsHtml = "";
    statsHtml += this.formatTemplate("level_stats_points", {points: this.formatNumber(this.xp)}) + "<br/>";
    statsHtml += this.formatTemplate("level_stats_carry", {value: this.gridManager.formatCarryVisual(carryNumber)});
    if (stats) stats.innerHTML = statsHtml;
    
    if (overlay) overlay.classList.remove("hidden");
    
    this.gridManager.tickFrozenCells();
  }

  completeLevelTransition() {
    if (!this.pendingTransition || !this.pendingTransition.active) return;
    const nextLevelIndex = this.pendingTransition.nextLevel;
    const carry = this.pendingTransition.carryNumber ?? null;
    this.pendingTransition = null;

    if (nextLevelIndex >= this.MAX_LEVEL - 1) {
      this.currentLevel = this.MAX_LEVEL - 1;
      this.carryNumber = carry;
      this.gridManager.initGame(this.currentLevel);
      this.saveGameState();
      this.achievementManager.updateAchievementProgress("firstGame", 1);
      this.showVictory();
    } else {
      this.currentLevel = nextLevelIndex;
      this.carryNumber = carry;
      this.gridManager.initGame(this.currentLevel);
      this.saveGameState();
    }
  }

  saveGameState() {
    // Извлекаем только числа из grid для сохранения
    const gridNumbers = [];
    if (this.grid && Array.isArray(this.grid)) {
      for (let x = 0; x < this.GRID_W; x++) {
        gridNumbers[x] = [];
        for (let y = 0; y < this.GRID_H; y++) {
          gridNumbers[x][y] = this.grid[x][y] ? this.grid[x][y].number : null;
        }
      }
    }
    
    const state = {
      version: 2,
      currentLevel: this.currentLevel,
      xp: this.xp,
      xpMultiplier: this.xpMultiplier,
      xpMultiplierTurns: this.xpMultiplierTurns,
      grid: gridNumbers,
      bonusInventory: this.bonusInventory,
      pendingTransition: this.pendingTransition,
      maxReachedNumber: this.maxReachedNumber,
      carryNumber: this.carryNumber,
      frozenCells: Object.fromEntries(this.frozenCells),
      stats: this.stats,
      achievements: this.achievements,
      wheelSpinsToday: this.wheelSpinsToday,
      lastWheelDay: this.lastWheelDay,
      animationEnabled: this.animationEnabled,
      soundEnabled: this.soundEnabled,
      theme: this.theme,
      lang: this.lang
    };
    
    this.storageManager.saveGameState(state);
    this.hasSave = true;
  }

  saveSettings() {
    this.settingsManager.saveSettings();
  }

  resetChain(reason = null) {
    this.isDragging = false;

    const oldSelected = [...this.selected]; // Сохраняем для очистки DOM
    this.selected = [];
    Chain.numbers = [];
    Chain.sum = 0;

    this.hidePreviewBubble();
    
    // Очищаем подсветку в DOM
    this.clearSelectionHighlight(oldSelected);

    if (reason === "invalid") {
      this.showMessage(this.t("chain_invalid"));
    }       
    this.gridManager.render();
  }
}

// Запуск игры при загрузке страницы
window.addEventListener("DOMContentLoaded", () => {
  window.game = new LostNumberGame();
});