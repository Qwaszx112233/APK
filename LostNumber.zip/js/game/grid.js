class GridManager {
  constructor(game) {
    this.game = game;
    this.isRendering = false;
  }

  initGame(levelIndex = 0) {
    this.game.currentLevel = levelIndex;
    const level = this.game.levels[this.game.currentLevel];

    this.game.selected = [];
    Chain.numbers = [];
    Chain.sum = 0;
    this.game.setGamePhase("playing");
    this.game.activeBonus = null;

    this.game.grid = [];
    
    for (let x = 0; x < this.game.GRID_W; x++) {
      this.game.grid[x] = [];
      for (let y = 0; y < this.game.GRID_H; y++) {
        let num;
        do {
          num = this.game.generateCellNumber();
        } while (num >= level.target);
        
        this.game.grid[x][y] = {
          number: num,
          merged: false,
          frozen: false
        };
      }
    }

    if (this.game.carryNumber) {
      const found = [];

      for (let x = 0; x < this.game.GRID_W; x++) {
        for (let y = 0; y < this.game.GRID_H; y++) {
          if (this.game.grid[x][y].number === this.game.carryNumber) {
            found.push({ x, y });
          }
        }
      }

      if (found.length > 1) {
        for (let i = 1; i < found.length; i++) {
          const p = found[i];
          this.game.grid[p.x][p.y].number = null;
          this.game.grid[p.x][p.y].merged = false;
        }
      }

      if (found.length === 0) {
        const rng = (this.game.state && this.game.state.rng) ? this.game.state.rng : null;
        let rx = rng ? rng.nextInt(this.game.GRID_W) : Math.floor(Math.random() * this.game.GRID_W);
                let ry = rng ? rng.nextInt(this.game.GRID_H) : Math.floor(Math.random() * this.game.GRID_H);

        this.game.grid[rx][ry].number = this.game.carryNumber;
        this.game.grid[rx][ry].merged = false;
      }
    }
    
    // ВАЖНО: После инициализации вызываем render
    this.performFullRender();
  }

  shuffleGrid() {
    const all = [];
    for (let x = 0; x < this.game.GRID_W; x++) {
      for (let y = 0; y < this.game.GRID_H; y++) {
        all.push(this.game.grid[x][y].number);
      }
    }
    
    for (let i = all.length - 1; i > 0; i--) {
      const rng = (this.game.state && this.game.state.rng) ? this.game.state.rng : null;
      const j = rng ? rng.nextInt(i + 1) : Math.floor(Math.random() * (i + 1));
      [all[i], all[j]] = [all[j], all[i]];
    }
    
    let k = 0;
    for (let x = 0; x < this.game.GRID_W; x++) {
      for (let y = 0; y < this.game.GRID_H; y++) {
        this.game.grid[x][y].number = all[k++]; 
        this.game.grid[x][y].merged = false;
        this.game.grid[x][y].frozen = false;
      }
    }
    
    // После перемешивания тоже перерисовываем
    this.performFullRender();
  }

  applyLocalGravity(removedCells) {
    console.log("Applying gravity for removed cells:", removedCells.length);
    
    // Создаем карту удаленных клеток
    const removedMap = {};
    removedCells.forEach(c => {
      if (!removedMap[c.x]) removedMap[c.x] = new Set();
      removedMap[c.x].add(c.y);
    });

    // Для каждого столбца применяем гравитацию
    for (let x = 0; x < this.game.GRID_W; x++) {
      const survivors = [];
      
      // Собираем все не-удаленные числа в столбце
      for (let y = 0; y < this.game.GRID_H; y++) {
        const isRemoved = removedMap[x]?.has(y);
        if (!isRemoved && this.game.grid[x][y] && this.game.grid[x][y].number !== null) {
          survivors.push({
            number: this.game.grid[x][y].number,
            y: y
          });
        }
      }
      
      // Очищаем столбец
      for (let y = 0; y < this.game.GRID_H; y++) {
        this.game.grid[x][y] = { 
          number: null, 
          merged: false,
          frozen: false
        };
      }
      
      // Заполняем столбец снизу вверх выжившими числами
      let writeY = this.game.GRID_H - 1;
      for (let i = survivors.length - 1; i >= 0; i--) {
        this.game.grid[x][writeY] = { 
          number: survivors[i].number, 
          merged: false,
          frozen: false
        };
        writeY--;
      }
      
      // Заполняем оставшиеся ячейки новыми числами
      while (writeY >= 0) {
        let newNum = this.game.generateCellNumber();
        const level = this.game.levels[this.game.currentLevel];
        while (newNum >= level.target) {
          newNum = this.game.generateCellNumber();
        }
        
        this.game.grid[x][writeY] = { 
          number: newNum, 
          merged: false,
          frozen: false
        };
        writeY--;
      }
    }
    
    console.log("Gravity applied successfully");
    // После применения гравитации перерисовываем
    this.performFullRender();
  }

  getCellFromPoint(clientX, clientY) {
    const el = document.elementFromPoint(clientX, clientY);
    if (!el) return null;
    const cell = el.classList.contains("cell") ? el : el.closest(".cell");
    if (!cell) return null;
    return { x: parseInt(cell.dataset.x, 10), y: parseInt(cell.dataset.y, 10) };
  }

  tickFrozenCells() {
    for (const [idx, turns] of this.game.frozenCells.entries()) {
      if (turns <= 1) {
        this.game.frozenCells.delete(idx);
      } else {
        this.game.frozenCells.set(idx, turns - 1);
      }
    }
    this.updateFrozenStates();
  }

  applyFreezePenalty() {
    const candidates = [];
    for (let x = 0; x < this.game.GRID_W; x++) {
      for (let y = 0; y < this.game.GRID_H; y++) {
        const idx = y * this.game.GRID_W + x;
        if (!this.game.frozenCells.has(idx) && this.game.grid[x][y].number !== null) {
          candidates.push({ x, y, idx });
        }
      }
    }
    
    if (candidates.length === 0) return;
    
    const rng = (this.game.state && this.game.state.rng) ? this.game.state.rng : null;
    const pick = candidates[(rng ? rng.nextInt(candidates.length) : Math.floor(Math.random() * candidates.length))];
    this.game.frozenCells.set(pick.idx, 3);
    this.updateFrozenStates();
  }

  // Метод рендера
  render() {
    if (this.isRendering) {
      return;
    }
    
    this.isRendering = true;
    
    const gridDiv = document.getElementById("grid");
    if (!gridDiv) {
      console.error("Grid div not found!");
      this.isRendering = false;
      return;
    }
    
    console.log("Rendering grid...");
    this.performFullRender();
    
    this.isRendering = false;
  }

  // Полная отрисовка
  performFullRender() {
    const gridDiv = document.getElementById("grid");
    if (!gridDiv) return;
    
    gridDiv.innerHTML = "";

    for (let y = 0; y < this.game.GRID_H; y++) {
      for (let x = 0; x < this.game.GRID_W; x++) {
        let cellData = this.game.grid[x][y];
        
        // Если это число, а не объект, преобразуем в объект
        if (typeof cellData === 'number' || cellData === null || cellData === undefined) {
          cellData = {
            number: typeof cellData === 'number' ? cellData : this.game.generateCellNumber(),
            merged: false,
            frozen: false
          };
          this.game.grid[x][y] = cellData;
        }

        let num = cellData.number;
        if (num == null) {
          num = this.game.generateCellNumber();
          cellData.number = num;
        }

        const cell = document.createElement("div");
        cell.className = "cell";
        cell.dataset.x = x;
        cell.dataset.y = y;
        cell.dataset.number = num;

        const idx = y * this.game.GRID_W + x;
        if (this.game.frozenCells.has(idx)) {
          cell.classList.add("frozen");
        }

        if (this.game.selected.some(s => s.x === x && s.y === y)) {
          cell.classList.add("selected");
        }
        
        if (cellData.merged) {
          cell.classList.add("merged");
        }

        const inner = document.createElement("div");
        inner.className = "cell-inner";
        inner.textContent = this.formatCarryVisual(num);
        cell.appendChild(inner);

        gridDiv.appendChild(cell);
      }
    }
    
    console.log(`Grid rendered with ${this.game.GRID_W * this.game.GRID_H} cells`);
  }
  
  // Отдельный метод для обновления frozen состояний
  updateFrozenStates() {
    const gridDiv = document.getElementById("grid");
    if (!gridDiv) return;
    
    const cells = gridDiv.querySelectorAll(".cell");
    cells.forEach(cell => {
      const x = parseInt(cell.dataset.x);
      const y = parseInt(cell.dataset.y);
      const idx = y * this.game.GRID_W + x;
      
      if (this.game.frozenCells.has(idx)) {
        cell.classList.add("frozen");
      } else {
        cell.classList.remove("frozen");
      }
    });
  }

  formatCarryVisual(num) {
    if (num === this.game.carryNumber) {
      return `✨${this.game.formatNumber(num)}✨`;
    }
    return this.game.formatNumber(num);
  }

  animateCarryAppear(x, y) {
    const gridDiv = document.getElementById("grid");
    const cell = gridDiv.querySelector(`.cell[data-x="${x}"][data-y="${y}"]`);
    if (!cell) return;
    cell.classList.add("carry");
    setTimeout(() => cell.classList.remove("carry"), 500);
  }

  animatePopping(cells, callback) {
    if (!this.game.animationEnabled) {
      if (callback) callback();
      return;
    }
    
    const gridDiv = document.getElementById("grid");
    cells.forEach(s => {
      const cell = gridDiv.querySelector(`.cell[data-x="${s.x}"][data-y="${s.y}"]`);
      if (cell) cell.classList.add("popping");
    });
    
    setTimeout(() => {
      if (callback) callback();
    }, 270);
  }

  animateGravity(removedCells, callback) {
    if (!this.game.animationEnabled) {
      if (callback) callback();
      return;
    }
    
    const gridDiv = document.getElementById("grid");
    const removedMap = {};
    removedCells.forEach(c => {
      if (!removedMap[c.x]) removedMap[c.x] = [];
      removedMap[c.x].push(c.y);
    });

    for (let x = 0; x < this.game.GRID_W; x++) {
      const ys = removedMap[x] ? removedMap[x].slice().sort((a, b) => a - b) : [];
      if (!ys.length) continue;

      for (let y = 0; y < this.game.GRID_H; y++) {
        const isRemoved = ys.includes(y);
        if (isRemoved) continue;

        let holesBelow = 0;
        ys.forEach(ry => {
          if (ry > y) holesBelow++;
        });

        if (holesBelow > 0) {
          const cell = gridDiv.querySelector(`.cell[data-x="${x}"][data-y="${y}"]`);
          if (cell) {
            cell.style.transition = "transform 0.25s ease";
            cell.style.transform = `translateY(${holesBelow * 100}%)`;
          }
        }
      }
    }

    setTimeout(() => {
      const cells = gridDiv.querySelectorAll(".cell");
      cells.forEach(c => {
        c.style.transition = "";
        c.style.transform = "";
      });
      if (callback) callback();
    }, 260);
  }

  countEmptyCells() {
    try {
      let c = 0;
      for (let x = 0; x < this.game.GRID_W; x++) {
        for (let y = 0; y < this.game.GRID_H; y++) {
          if ((this.game.grid[x][y]?.value || 0) === 0) c++;
        }
      }
      return c;
    } catch (e) {
      return 0;
    }
  }

}
