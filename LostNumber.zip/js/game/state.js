class GameState {
  constructor() {
    this.GRID_W = 5;
    this.GRID_H = 8;
    this.MAX_DAILY_SPINS = 20;

    this.levels = this.generateLevels(40);
    this.MAX_LEVEL = this.levels.length;

    this.currentLevel = 0;
    this.xp = 0;
    this.xpMultiplier = 1;
    this.xpMultiplierTurns = 0;
    
    this.maxReachedNumber = 8;
    this.carryNumber = null;
    
    this.grid = [];
    this.selected = [];
    this.isDragging = false;
    this.activeBonus = null;
    
    this.bonusInventory = { 
      destroy: 0, 
      shuffle: 0, 
      explosion: 0
    };

    this.frozenCells = new Map();
    this.stats = this.defaultStats();
    this.achievements = this.defaultAchievements();
    
    this.pendingTransition = null;
    this.hasSave = false;
    
    this.wheelSpinsToday = 0;
    this.lastWheelDay = this.getTodayKey();
    
    this.animationEnabled = true;
    this.lang = "ua";
    this.soundEnabled = true;
    this.theme = "dusk";
    
    // Seeded RNG (инициализируется в main.js)
    this.sessionSeed = 0;
    this.dailySeed = 0;
    this.currentSeed = 0;
    this.rng = null;
    
    this.screenState = "mainMenu";
    this.gamePhase = "idle";
    this.setGamePhase("playing");
    
    this.core = new GameCore(this);
    
    this.dailyQuests = null;
  }

  generateLevels(count) {
    const levels = [];
    let target = 64;
    let baseNumbers = [2, 4, 8];

    for (let i = 0; i < count; i++) {
      const numbers = [...baseNumbers];
      const newNumbers = this.generateNewNumbers(target);

      levels.push({ target, numbers, newNumbers });

      target *= 2;

      if (i % 3 === 2 && baseNumbers.length < 7) {
        baseNumbers.push(baseNumbers[baseNumbers.length - 1] * 2);
      }
    }

    return levels;
  }

  generateNewNumbers(target) {
    const arr = [];
    let num = target/8;
    for (let i=0;i<8;i++) {
      if (num <= target) {
        arr.unshift(num);
        num *= 2;
      }
    }
    return arr;
  }

  defaultStats() {
    return {
      gamesPlayed: 0,
      levelsCompleted: 0,
      highestLevel: 0,
      totalXP: 0,
      totalMerges: 0,
      longestChain: 0,
      bonusesUsed: 0,
      wheelSpins: 0
    };
  }

  defaultAchievements() {
    return {
      firstGame: { unlocked: false, progress: 0, max: 1 },
      level10: { unlocked: false, progress: 0, max: 10 },
      level25: { unlocked: false, progress: 0, max: 25 },
      xp1000: { unlocked: false, progress: 0, max: 1000 },
      xp5000: { unlocked: false, progress: 0, max: 5000 },
      chain5: { unlocked: false, progress: 0, max: 5 },
      chain10: { unlocked: false, progress: 0, max: 10 },
      useAllBonuses: { unlocked: false, progress: 0, max: 5 },
      spinWheel: { unlocked: false, progress: 0, max: 1 },
      spinWheel10: { unlocked: false, progress: 0, max: 10 }
    };
  }

  getTodayKey() {
    const d = new Date();
    return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;
  }

  setGamePhase(phase) {
    this.gamePhase = phase;

    if (phase === "playing") this.gameState = "playing";
    else if (phase === "win") this.gameState = "win";
    else if (phase === "transitioning") this.gameState = "transition";
    else if (phase === "menu") this.gameState = "menu";
    else this.gameState = "blocked";
  }

  resetRuntimeState() {
    this.isDragging = false;
    this.activeBonus = null;
    this.selected = [];
    Chain.numbers = [];
    Chain.sum = 0;
  }

  getAllowedNumbers() {
    const WINDOW = 9;
    const max = this.maxReachedNumber;
    
    let arr = [];
    let num = max;
    
    while (arr.length < WINDOW && num >= 2) {
      arr.unshift(num);
      num /= 2;
    }
    
    if (arr.length < WINDOW) {
      let current = max;
      while (arr.length < WINDOW) {
        current *= 2;
        arr.push(current);
      }
    }
    
    return arr;
  }

  generateCellNumber() {
    const allowed = this.getAllowedNumbers();
    const levelTarget = this.levels?.[this.currentLevel]?.target;
    
    const filtered = allowed.filter(n => n !== this.carryNumber && n !== levelTarget);
    
    if (filtered.length === 0) {
      // Если нет доступных чисел, вернем минимальное
      return 2;
    }
    
    const items = filtered.map((value, index) => ({
      value,
      weight: 1 / (2 ** index)
    }));
    
    return this.pickWeighted(items).value;
  }

  pickWeighted(items) {
    let total = 0;
    for (const it of items) total += it.weight;

    let r = (this.rng ? this.rng.nextFloat() : Math.random()) * total;
    for (const it of items) {
      r -= it.weight;
      if (r <= 0) return it;
    }
    return items[items.length - 1];
  }

  formatNumber(num) {
    if (!Number.isFinite(num)) return "∞";
    if (num <= 0) return "0";

    if (num < 1000) {
      const lang = this.lang === "ua" ? "uk" : this.lang;
      return num.toLocaleString(lang);
    }

    const baseSuffixes = [
      "k", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc"
    ];

    const tier = Math.floor(Math.log10(num) / 3);

    let suffix;
    if (tier - 1 < baseSuffixes.length) {
      suffix = baseSuffixes[tier - 1];
    } else {
      suffix = this.generateAASuffix(tier - baseSuffixes.length);
    }

    const scaled = num / 10 ** (tier * 3);

    let formatted;
    if (scaled < 10) {
      formatted = scaled.toFixed(2);
    } else if (scaled < 100) {
      formatted = scaled.toFixed(1);
    } else {
      formatted = Math.floor(scaled).toString();
    }

    formatted = formatted.replace(/\.0+$|(\.\d*[1-9])0+$/, "$1");

    return formatted + suffix;
  }

  generateAASuffix(index) {
    let result = "";
    index++;

    while (index > 0) {
      index--;
      result = String.fromCharCode(97 + (index % 26)) + result;
      index = Math.floor(index / 26);
    }

    return result;
  }

  getWheelCost() {
    const BASE = 25;
    const FREE = 5;
    const STEP = 15;

    if (this.wheelSpinsToday < FREE) return BASE;
    return BASE + (this.wheelSpinsToday - FREE) * STEP;
  }

  checkWheelDailyReset() {
    const today = this.getTodayKey();
    if (this.lastWheelDay !== today) {
      this.lastWheelDay = today;
      this.wheelSpinsToday = 0;
    }
  }

  baseXPByLen(len) {
    if (len <= 1) return 0;
    if (len === 2) return 4;
    if (len === 3) return 8;
    if (len === 4) return 12;
    if (len === 5) return 18;
    return 25;
  }

  levelXPMult() {
    return 1 + (this.currentLevel+1)*0.06;
  }

  calculateXP(len) {
    const base = this.baseXPByLen(len);
    let xp = Math.max(0, Math.round(base * this.levelXPMult()));
    
    if (this.xpMultiplier > 1 && this.xpMultiplierTurns > 0) {
      xp = Math.round(xp * this.xpMultiplier);
      this.xpMultiplierTurns--;
      if (this.xpMultiplierTurns <= 0) {
        this.xpMultiplier = 1;
      }
    }
    
    return xp;
  }

  updateDailyQuests(dailyQuests) {
    this.dailyQuests = dailyQuests;
  }
}