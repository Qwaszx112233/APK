class BonusManager {
  constructor(game) {
    this.game = game;
  }

  activateBonus(type) {
    if (this.game.activeBonus === type) {
      this.game.activeBonus = null;
      this.updateBonusesUI();
      return;
    }
    
    if (this.game.bonusInventory[type] <= 0) {
      this.showMessage(this.game.t("no_bonus"));
      return;
    }
    
    if (type === "shuffle") {
      this.game.bonusInventory.shuffle--;
      this.game.stats.bonusesUsed++;
      this.animatedShuffleGrid();
      this.updateBonusesUI();
      this.showMessage(this.game.t("shuffle_done"));
      
      if (this.game.achievementManager) {
        this.game.achievementManager.updateAchievementProgress("useAllBonuses", 1);
      }
      
      if (this.game.dailyQuestManager) {
        this.game.dailyQuestManager.completeDailyQuest("useBonus");
      }
      return;
    }
    
    this.game.activeBonus = type;
    this.updateBonusesUI();
    this.showMessage(this.game.t("choose_cell_bonus"));
  }

  animatedShuffleGrid() {
    const gridDiv = document.getElementById("grid");
    const cells = gridDiv ? gridDiv.querySelectorAll(".cell") : [];
    cells.forEach(c => c.classList.add("shuffle-anim"));
    
    setTimeout(() => {
      if (this.game.gridManager) {
        this.game.gridManager.shuffleGrid();
      }
      cells.forEach(c => c.classList.remove("shuffle-anim"));
    }, 350);
  }

  useDestroyBonus(x, y) {
    if (this.game.bonusInventory.destroy <= 0) {
      this.showMessage(this.game.t("no_bonus"));
      this.game.activeBonus = null;
      this.updateBonusesUI();
      return;
    }
    
    this.game.bonusInventory.destroy--;
    this.game.stats.bonusesUsed++;

    const removedCells = [{x, y}];

    if (this.game.gridManager) {
      this.game.gridManager.animatePopping(removedCells, () => {
        this.game.gridManager.animateGravity(removedCells, () => {
          // ВАЖНО: Вызываем гравитацию
          this.game.gridManager.applyLocalGravity(removedCells);
          this.game.activeBonus = null;
          this.updateBonusesUI();
          this.showMessage(this.game.t("destroy_done"));
          
          if (this.game.achievementManager) {
            this.game.achievementManager.updateAchievementProgress("useAllBonuses", 1);
          }
          
          if (this.game.dailyQuestManager) {
            this.game.dailyQuestManager.completeDailyQuest("useBonus");
          }
        });
      });
    }
  }

  useExplosionBonus(x, y) {
    if (this.game.bonusInventory.explosion <= 0) {
      this.showMessage(this.game.t("no_bonus"));
      this.game.activeBonus = null;
      this.updateBonusesUI();
      return;
    }
    
    this.game.bonusInventory.explosion--;
    this.game.stats.bonusesUsed++;

    const removedCells = [];
    for (let dx = -1; dx <= 1; dx++) {
      for (let dy = -1; dy <= 1; dy++) {
        const nx = x + dx, ny = y + dy;
        if (nx >= 0 && nx < this.game.GRID_W && ny >= 0 && ny < this.game.GRID_H) {
          removedCells.push({x: nx, y: ny});
        }
      }
    }

    if (this.game.gridManager) {
      this.game.gridManager.animatePopping(removedCells, () => {
        this.game.gridManager.animateGravity(removedCells, () => {
          // ВАЖНО: Вызываем гравитацию
          this.game.gridManager.applyLocalGravity(removedCells);
          this.game.activeBonus = null;
          this.updateBonusesUI();
          this.showMessage(this.game.t("explosion_done"));
          
          if (this.game.achievementManager) {
            this.game.achievementManager.updateAchievementProgress("useAllBonuses", 1);
          }
          
          if (this.game.dailyQuestManager) {
            this.game.dailyQuestManager.completeDailyQuest("useBonus");
          }
        });
      });
    }
  }

  updateBonusesUI() {
    const countExplosion = document.getElementById("count-explosion");
    const countShuffle = document.getElementById("count-shuffle");
    const countDestroy = document.getElementById("count-destroy");
    
    const bonusExplosion = document.getElementById("bonus-explosion");
    const bonusShuffle = document.getElementById("bonus-shuffle");
    const bonusDestroy = document.getElementById("bonus-destroy");

    const b = this.game.bonusInventory;

    if (countExplosion) countExplosion.textContent = b.explosion;
    if (countShuffle) countShuffle.textContent = b.shuffle;
    if (countDestroy) countDestroy.textContent = b.destroy;

    if (bonusExplosion) bonusExplosion.disabled = b.explosion <= 0 && this.game.activeBonus !== "explosion";
    if (bonusShuffle) bonusShuffle.disabled = b.shuffle <= 0 && this.game.activeBonus !== "shuffle";
    if (bonusDestroy) bonusDestroy.disabled = b.destroy <= 0 && this.game.activeBonus !== "destroy";

    if (bonusExplosion) bonusExplosion.classList.toggle("active", this.game.activeBonus === "explosion");
    if (bonusShuffle) bonusShuffle.classList.toggle("active", this.game.activeBonus === "shuffle");
    if (bonusDestroy) bonusDestroy.classList.toggle("active", this.game.activeBonus === "destroy");
  }

  showMessage(text) {
    this.game.showMessage(text);
  }
}