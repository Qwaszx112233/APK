class WheelManager {
  constructor(game) {
    this.game = game;
    this.wheelSectors = [
      { id: 0, type: "xp_plus", label: "XP+", color: "#4CAF50", effect: "xp", value: 15, messageKey: "wheel_xp_plus" },
      { id: 1, type: "xp_minus", label: "XP−", color: "#F44336", effect: "xp", value: -10, messageKey: "wheel_xp_minus" },
      { id: 2, type: "shuffle", label: "🔄", color: "#2196F3", effect: "bonus", value: "shuffle", messageKey: "wheel_bonus_shuffle_added" },
      { id: 3, type: "destroy", label: "🔨", color: "#FF9800", effect: "bonus", value: "destroy", messageKey: "wheel_bonus_destroy_added" },
      { id: 4, type: "explosion", label: "💥", color: "#9C27B0", effect: "bonus", value: "explosion", messageKey: "wheel_bonus_explosion_added" },
      { id: 5, type: "xp_multiplier", label: "×2 XP", color: "#FFC107", effect: "multiplier", value: 5, messageKey: "wheel_xp_multiplier" },
      { id: 6, type: "gift", label: "🎁", color: "#00BCD4", effect: "gift", value: null, messageKey: "wheel_gift" },
      { id: 7, type: "freeze", label: "❄️", color: "#607D8B", effect: "freeze", value: 3, messageKey: "freeze_penalty" }
    ];
  }

  handleWheel() {
    this.game.checkWheelDailyReset();

    if (this.game.wheelSpinsToday >= this.game.MAX_DAILY_SPINS) {
      this.game.showMessage(this.game.t("wheel_limit_reached"));
      return;
    }

    if (this.game.xp < this.game.getWheelCost()) {
      this.game.showMessage(this.game.t("dice_not_enough"));
      return;
    }

    this.initWheel();
    document.getElementById("wheelOverlay").classList.remove("hidden");
    this.updateWheelUI();
  }

  initWheel() {
    const canvas = document.getElementById("fortuneWheel");
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 10;

    this.wheelCtx = ctx;
    this.wheelCenterX = centerX;
    this.wheelCenterY = centerY;
    this.wheelRadius = radius;

    this.drawWheel();
  }

  drawWheel() {
    if (!this.wheelCtx) return;
    
    const ctx = this.wheelCtx;
    const centerX = this.wheelCenterX;
    const centerY = this.wheelCenterY;
    const radius = this.wheelRadius;
    
    ctx.clearRect(0, 0, 300, 300);
    
    const anglePerSector = (2 * Math.PI) / this.wheelSectors.length;

    this.wheelSectors.forEach((sector, i) => {
      const startAngle = i * anglePerSector;
      const endAngle = (i + 1) * anglePerSector;

      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = sector.color;
      ctx.fill();
      ctx.strokeStyle = "#FFF";
      ctx.lineWidth = 2;
      ctx.stroke();

      const midAngle = startAngle + anglePerSector / 2;
      const textX = centerX + (radius * 0.7) * Math.cos(midAngle);
      const textY = centerY + (radius * 0.7) * Math.sin(midAngle);

      ctx.save();
      ctx.translate(textX, textY);
      ctx.rotate(midAngle + Math.PI / 2);
      ctx.textAlign = "center";
      ctx.fillStyle = "#FFF";
      ctx.font = "bold 16px Arial";
      ctx.fillText(this.game.t(`wheel_sector_${sector.type}`), 0, 0);
      ctx.restore();
    });

    ctx.beginPath();
    ctx.arc(centerX, centerY, 10, 0, 2 * Math.PI);
    ctx.fillStyle = "#FF4081";
    ctx.fill();
    ctx.strokeStyle = "#FFF";
    ctx.lineWidth = 3;
    ctx.stroke();
  }

  spinWheel() {
    const cost = this.game.getWheelCost();
    if (this.game.xp < cost) {
      this.game.showMessage(this.game.t("dice_not_enough"));
      return;
    }

    if (this.game.wheelSpinsToday >= this.game.MAX_DAILY_SPINS) {
      this.game.showMessage(this.game.t("wheel_limit_reached"));
      return;
    }

    this.game.xp -= cost;
    this.game.wheelSpinsToday++;
    this.game.stats.wheelSpins++;

    // ФИКС: Правильный вызов методов через achievementManager
    if (this.game.achievementManager) {
      this.game.achievementManager.updateAchievementProgress("spinWheel", 1);
      this.game.achievementManager.updateAchievementProgress("spinWheel10", 1);
    }
    
    if (this.game.dailyQuestManager) {
      this.game.dailyQuestManager.completeDailyQuest("spinWheel");
    }

    this.game.updateXPBar();
    this.updateWheelUI();

    const spinBtn = document.getElementById("spinWheelBtn");
    if (spinBtn) {
      spinBtn.disabled = true;
      spinBtn.textContent = this.game.t("wheel_spinning");
    }

    const sectorCount = this.wheelSectors.length;
    const rng = (this.game.state && this.game.state.rng) ? this.game.state.rng : null;
    const randomSector = rng ? rng.nextInt(sectorCount) : Math.floor(Math.random() * sectorCount);
    const extraRotations = 5;
    const totalRotation = (extraRotations * 2 * Math.PI) + (randomSector * (2 * Math.PI / sectorCount));

    const wheel = document.getElementById("fortuneWheel");
    if (wheel) {
      wheel.style.transition = "transform 3.5s cubic-bezier(0.2, 0.8, 0.3, 1)";
      wheel.style.transform = `rotate(${totalRotation}rad)`;
    }

    setTimeout(() => {
      // результат и подсветка
      this.highlightWheelSector(randomSector);
      
      const result = this.applyWheelResult(this.wheelSectors[randomSector]);
      
      const resultEl = document.getElementById("wheelResult");
      if (resultEl) {
        resultEl.textContent = result.message;
        // микро-анимация
        resultEl.classList.remove("anim");
        // reflow
        void resultEl.offsetWidth;
        resultEl.classList.add("anim");
      }
      
      setTimeout(() => {
        if (this.game.bonusManager) {
          this.game.bonusManager.updateBonusesUI();
        }
        this.game.updateXPBar();
        this.clearWheelHighlight();

        // Разблокируем кнопку только когда результат убран
        const spinBtn2 = document.getElementById("spinWheelBtn");
        if (spinBtn2) {
          spinBtn2.disabled = false;
          spinBtn2.textContent = this.game.formatTemplate("btn_spin_wheel", { cost: this.game.getWheelCost() });
        }

        // очистим текст результата (чтобы авто-блок работал)
        const resultEl2 = document.getElementById("wheelResult");
        if (resultEl2) resultEl2.textContent = "";

      }, 2000);
    }, 3500);
  }

  applyWheelResult(sector) {
    let message = "";
    
    switch(sector.effect) {
      case "xp":
        this.game.xp += sector.value;
        this.game.stats.totalXP += sector.value;
        message = this.game.t(sector.messageKey);
        break;
        
      case "bonus":
        this.game.bonusInventory[sector.value]++;
        message = this.game.t(sector.messageKey);
        break;
        
      case "multiplier":
        this.game.xpMultiplier = 2;
        this.game.xpMultiplierTurns = sector.value;
        message = this.game.formatTemplate(sector.messageKey, { turns: sector.value });
        this.game.updateMultiplierIndicator();
        break;
        
      case "gift":
        const gifts = [
          { type: "xp", value: 50, messageKey: "wheel_gift_xp50" },
          { type: "bonus", value: "explosion", amount: 2, messageKey: "wheel_gift_explosion2" },
          { type: "xp", value: 30, messageKey: "wheel_gift_xp30" }
        ];
        const rng = (this.game.state && this.game.state.rng) ? this.game.state.rng : null;
        const gift = gifts[(rng ? rng.nextInt(gifts.length) : Math.floor(Math.random() * gifts.length))];
        
        if (gift.type === "xp") {
          this.game.xp += gift.value;
          this.game.stats.totalXP += gift.value;
        } else if (gift.type === "bonus") {
          this.game.bonusInventory[gift.value] += gift.amount;
        }
        message = this.game.t(gift.messageKey);
        break;
        
      case "freeze":
        if (this.game.gridManager) {
          this.game.gridManager.applyFreezePenalty();
        }
        message = this.game.formatTemplate(sector.messageKey, { turns: sector.value });
        break;
        
      default:
        message = this.game.t(sector.messageKey);
    }
    
    return { sector, message };
  }

  closeWheel() {
    const wheelOverlay = document.getElementById("wheelOverlay");
    if (wheelOverlay) {
      wheelOverlay.classList.add("hidden");
    }
    this.updateWheelUI();
  }

  highlightWheelSector(sectorIndex) {
    const canvas = document.getElementById("fortuneWheel");
    if (!canvas) return;
    
    const ctx = canvas.getContext("2d");
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 10;
    
    const anglePerSector = (2 * Math.PI) / this.wheelSectors.length;
    const startAngle = sectorIndex * anglePerSector;
    const endAngle = (sectorIndex + 1) * anglePerSector;
    
    this._blinkCount = 0;
    this._maxBlinks = 3;
    
    const blink = () => {
      if (this._blinkCount >= this._maxBlinks * 2) {
        this.clearWheelHighlight();

        // Разблокируем кнопку только когда результат убран
        const spinBtn2 = document.getElementById("spinWheelBtn");
        if (spinBtn2) {
          spinBtn2.disabled = false;
          spinBtn2.textContent = this.game.formatTemplate("btn_spin_wheel", { cost: this.game.getWheelCost() });
        }

        // очистим текст результата (чтобы авто-блок работал)
        const resultEl2 = document.getElementById("wheelResult");
        if (resultEl2) resultEl2.textContent = "";

        return;
      }
      
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      this.drawWheel();
      
      if (this._blinkCount % 2 === 0) {
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius + 3, startAngle, endAngle);
        ctx.save();
        ctx.shadowBlur = 0;
        ctx.shadowColor = "transparent";

        // заливка только сектора (без бликов по всему колесу)
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY, radius, startAngle, endAngle);
        ctx.closePath();
        ctx.fillStyle = "rgba(255, 215, 0, 0.22)";
        ctx.fill();

        // контур сектора
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY, radius + 2, startAngle, endAngle);
        ctx.closePath();
        ctx.lineWidth = 4;
        ctx.strokeStyle = "#FFD700";
        ctx.stroke();
        ctx.restore();
      }
      
      this._blinkCount++;
      setTimeout(blink, 300);
    };
    
    blink();
  }

  clearWheelHighlight() {
    const canvas = document.getElementById("fortuneWheel");
    if (!canvas) return;
    
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    this.drawWheel();
  }

  updateWheelUI() {
    const cost = this.game.getWheelCost();
    const remainingSpins = Math.max(0, this.game.MAX_DAILY_SPINS - this.game.wheelSpinsToday);

    const xpLabel = document.getElementById("wheelXpLabel");
    if (xpLabel) {
      xpLabel.textContent = this.game.formatTemplate("wheel_xp_header", { xp: this.game.formatNumber(this.game.xp) });
    }

    const wheelCostLabel = document.getElementById("wheelCostLabel");
    if (wheelCostLabel) wheelCostLabel.textContent = cost;

    const wheelRemainingSpins = document.getElementById("wheelRemainingSpins");
    if (wheelRemainingSpins) wheelRemainingSpins.textContent = `(${remainingSpins})`;

    const spinBtn = document.getElementById("spinWheelBtn");
    if (spinBtn) {
      spinBtn.textContent = this.game.formatTemplate("btn_spin_wheel", { cost });
    }

    const dailyInfo = document.getElementById("wheelDailyInfo");
    if (dailyInfo) {
      dailyInfo.innerHTML = `
        ${this.game.formatTemplate("wheel_daily_limit", {used: this.game.wheelSpinsToday, total: this.game.MAX_DAILY_SPINS})}<br>
        <small>${this.game.t("wheel_daily_reset")}</small>
      `;
    }

    const wheelBtn = document.getElementById("bonus-wheel");
    if (wheelBtn) {
      wheelBtn.disabled = this.game.wheelSpinsToday >= this.game.MAX_DAILY_SPINS;
      if (wheelBtn.disabled) {
        wheelBtn.style.opacity = "0.4";
        wheelBtn.title = this.game.t("wheel_limit_reached");
      } else {
        wheelBtn.style.opacity = "1";
        wheelBtn.title = this.game.t("bonus_wheel_title");
      }
    }

    const wheelSpinsUsed = document.getElementById("wheelSpinsUsed");
    const wheelSpinsTotal = document.getElementById("wheelSpinsTotal");
    if (wheelSpinsUsed) wheelSpinsUsed.textContent = this.game.wheelSpinsToday;
    if (wheelSpinsTotal) wheelSpinsTotal.textContent = this.game.MAX_DAILY_SPINS;
  }
}