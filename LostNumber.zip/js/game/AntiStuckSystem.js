// AntiStuckSystem.js — мягкая помощь когда игрок застрял
class AntiStuckSystem {
  constructor(game) {
    this.game = game;
    this.levelStartAt = Date.now();
    this.usedHintThisLevel = false;
  }

  onLevelStart() {
    this.levelStartAt = Date.now();
    this.usedHintThisLevel = false;
  }

  // Простейшая проверка: есть ли хоть один ход из 2 клеток (adjacent) который дает степень 2
  checkPossibleMoves() {
    try {
      const g = this.game;
      const W = g.GRID_W, H = g.GRID_H;
      const grid = g.grid;
      for (let y = 0; y < H; y++) {
        for (let x = 0; x < W; x++) {
          const a = grid[x][y];
          if (!a) continue;
          const neigh = [[x+1,y],[x-1,y],[x,y+1],[x,y-1]];
          for (const [nx,ny] of neigh) {
            if (nx<0||ny<0||nx>=W||ny>=H) continue;
            const b = grid[nx][ny];
            if (!b) continue;
            const av = a?.value || 0;
            const bv = b?.value || 0;
            if (!av || !bv) continue;
            const sum = av + bv;
            if (g.core && g.core.isPowerOfTwo && g.core.isPowerOfTwo(sum)) return true;
          }
        }
      }
      return false;
    } catch (e) {
      try { if (typeof ErrorHandler !== "undefined") ErrorHandler.handle(e, { where: "AntiStuckSystem.checkPossibleMoves" }); } catch (_) {}
      return true; // если не уверены — не мешаем
    }
  }

  maybeOfferHelp() {
    const g = this.game;
    if (this.usedHintThisLevel) return;
    const stuckLong = (Date.now() - this.levelStartAt) > 5 * 60 * 1000;
    const noMoves = !this.checkPossibleMoves();

    if (stuckLong || noMoves) {
      this.usedHintThisLevel = true;
      g.showMessage(g.t("need_help") || "Нужна помощь? Открываю подсказку…");
      // самый мягкий вариант: подсветить возможный ход (если есть preview система)
      // если нет ходов — дать бесплатный спин
      try {
        if (noMoves && g.wheelManager) {
          g.wheelManager.openWheelOverlay();
          // бесплатный спин: просто не списываем XP
          g.showMessage(g.t("free_spin") || "Бесплатный спин!");
        }
      } catch (_) {}
    }
  }
}
