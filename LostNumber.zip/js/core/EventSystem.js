// EventSystem.js — простой EventBus с приоритетами
class EventSystem {
  constructor() {
    this._map = new Map(); // event -> [{cb, once, pr}]
  }

  on(event, callback, priority = 0) {
    if (!event || typeof callback !== "function") return () => {};
    const arr = this._map.get(event) || [];
    arr.push({ cb: callback, once: false, pr: priority | 0 });
    arr.sort((a, b) => (b.pr - a.pr));
    this._map.set(event, arr);
    return () => this.off(event, callback);
  }

  once(event, callback, priority = 0) {
    if (!event || typeof callback !== "function") return () => {};
    const arr = this._map.get(event) || [];
    arr.push({ cb: callback, once: true, pr: priority | 0 });
    arr.sort((a, b) => (b.pr - a.pr));
    this._map.set(event, arr);
    return () => this.off(event, callback);
  }

  off(event, callback) {
    const arr = this._map.get(event);
    if (!arr) return;
    this._map.set(event, arr.filter(it => it.cb !== callback));
  }

  emit(event, data) {
    const arr = this._map.get(event);
    if (!arr || !arr.length) return;
    // копия: чтобы можно было off внутри cb
    const copy = arr.slice();
    for (const it of copy) {
      try {
        it.cb(data);
      } catch (e) {
        try { if (typeof ErrorHandler !== "undefined") ErrorHandler.handle(e, { where: `EventSystem.emit:${event}` }); } catch (_) {}
      }
      if (it.once) this.off(event, it.cb);
    }
  }
}
