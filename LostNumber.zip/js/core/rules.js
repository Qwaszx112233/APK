const Rules = {
  isPowerOfTwo: function(n) {
    return Number.isInteger(n) && n > 0 && (n & (n - 1)) === 0;
  },

  isAdjacent: function(a, b) {
    return Math.abs(a.x - b.x) <= 1 && Math.abs(a.y - b.y) <= 1;
  },

  baseXPByLen: function(len) {
    if (len <= 1) return 0;
    if (len === 2) return 4;
    if (len === 3) return 8;
    if (len === 4) return 12;
    if (len === 5) return 18;
    return 25;
  }
};