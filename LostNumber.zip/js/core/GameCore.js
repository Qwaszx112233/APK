// ==================== GAME CORE ====================
class GameCore {
  constructor(game) {
    this.game = game;
  }

  validateMove(state) {
    const { selected, grid, chain, frozenCells } = state;
    
    if (selected.length > 0) {
      const firstCell = selected[0];
      const firstIdx = firstCell.y * this.game.GRID_W + firstCell.x;
      if (frozenCells.has(firstIdx)) {
        return { valid: false, reason: 'cell_frozen' };
      }
    }

    if (selected.length < 2) {
      return { valid: false, reason: 'chain_too_short' };
    }

    for (let i = 1; i < selected.length; i++) {
      const prev = selected[i - 1];
      const curr = selected[i];
      
      if (!this.isAdjacent(prev, curr)) {
        return { valid: false, reason: 'not_adjacent' };
      }

      const currIdx = curr.y * this.game.GRID_W + curr.x;
      if (frozenCells.has(currIdx)) {
        return { valid: false, reason: 'cell_frozen' };
      }

      const prevNum = grid[prev.x][prev.y].number;
      const currNum = grid[curr.x][curr.y].number;
      const currentSum = chain.numbers.slice(0, i).reduce((a, b) => a + b, 0);
      
      if (!this.isValidNextNumber(currNum, prevNum, currentSum)) {
        return { valid: false, reason: 'invalid_number' };
      }
    }

    const firstNum = chain.numbers[0];
    const sum = chain.sum;
    
    if (!this.isPowerOfTwo(sum) || sum <= firstNum) {
      return { valid: false, reason: 'invalid_sum' };
    }

    return { valid: true };
  }

  isAdjacent(a, b) {
    return Math.abs(a.x - b.x) <= 1 && Math.abs(a.y - b.y) <= 1;
  }

  isValidNextNumber(next, prev, chainSum) {
    if (next === prev) return true;
    if (next === prev * 2) return true;
    if (next === chainSum && this.isPowerOfTwo(chainSum) && chainSum >= prev) return true;
    return false;
  }

  isPowerOfTwo(n) {
    // ИСПРАВЛЕННАЯ РЕАЛИЗАЦИЯ - безопасна для больших чисел
    return Number.isInteger(n) && n > 0 && (n & (n - 1)) === 0;
  }

  canFinishChain(chain) {
    if (chain.numbers.length < 2) return false;
    const sum = chain.sum;
    const first = chain.numbers[0];
    return this.isPowerOfTwo(sum) && sum > first;
  }
}